package com.webo.app.twowheelerloan.loansansction.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwoWheelerLoanSanctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
